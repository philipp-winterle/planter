--
-- PostgreSQL database dump
--

-- Dumped from database version 13.7 (Debian 13.7-1.pgdg110+1)
-- Dumped by pg_dump version 13.7 (Debian 13.7-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS directus;
--
-- Name: directus; Type: DATABASE; Schema: -; Owner: directus
--

CREATE DATABASE directus WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE directus OWNER TO directus;

\connect directus

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: directus; Type: DATABASE PROPERTIES; Schema: -; Owner: directus
--

ALTER DATABASE directus SET search_path TO '$user', 'public', 'topology', 'tiger';


\connect directus

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: directus
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO directus;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: directus
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO directus;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: directus
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO directus;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: directus
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: directus_activity; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_activity (
    id integer NOT NULL,
    action character varying(45) NOT NULL,
    "user" uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip character varying(50),
    user_agent character varying(255),
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    comment text
);


ALTER TABLE public.directus_activity OWNER TO directus;

--
-- Name: directus_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_activity_id_seq OWNER TO directus;

--
-- Name: directus_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_activity_id_seq OWNED BY public.directus_activity.id;


--
-- Name: directus_collections; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_collections (
    collection character varying(64) NOT NULL,
    icon character varying(30),
    note text,
    display_template character varying(255),
    hidden boolean DEFAULT false NOT NULL,
    singleton boolean DEFAULT false NOT NULL,
    translations json,
    archive_field character varying(64),
    archive_app_filter boolean DEFAULT true NOT NULL,
    archive_value character varying(255),
    unarchive_value character varying(255),
    sort_field character varying(64),
    accountability character varying(255) DEFAULT 'all'::character varying,
    color character varying(255),
    item_duplication_fields json,
    sort integer,
    "group" character varying(64),
    collapse character varying(255) DEFAULT 'open'::character varying NOT NULL
);


ALTER TABLE public.directus_collections OWNER TO directus;

--
-- Name: directus_dashboards; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_dashboards (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(30) DEFAULT 'dashboard'::character varying NOT NULL,
    note text,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid,
    color character varying(255)
);


ALTER TABLE public.directus_dashboards OWNER TO directus;

--
-- Name: directus_fields; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_fields (
    id integer NOT NULL,
    collection character varying(64) NOT NULL,
    field character varying(64) NOT NULL,
    special character varying(64),
    interface character varying(64),
    options json,
    display character varying(64),
    display_options json,
    readonly boolean DEFAULT false NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    sort integer,
    width character varying(30) DEFAULT 'full'::character varying,
    translations json,
    note text,
    conditions json,
    required boolean DEFAULT false,
    "group" character varying(64),
    validation json,
    validation_message text
);


ALTER TABLE public.directus_fields OWNER TO directus;

--
-- Name: directus_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_fields_id_seq OWNER TO directus;

--
-- Name: directus_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_fields_id_seq OWNED BY public.directus_fields.id;


--
-- Name: directus_files; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_files (
    id uuid NOT NULL,
    storage character varying(255) NOT NULL,
    filename_disk character varying(255),
    filename_download character varying(255) NOT NULL,
    title character varying(255),
    type character varying(255),
    folder uuid,
    uploaded_by uuid,
    uploaded_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by uuid,
    modified_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    charset character varying(50),
    filesize bigint,
    width integer,
    height integer,
    duration integer,
    embed character varying(200),
    description text,
    location text,
    tags text,
    metadata json
);


ALTER TABLE public.directus_files OWNER TO directus;

--
-- Name: directus_flows; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_flows (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(30),
    color character varying(255),
    description text,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    trigger character varying(255),
    accountability character varying(255) DEFAULT 'all'::character varying,
    options json,
    operation uuid,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


ALTER TABLE public.directus_flows OWNER TO directus;

--
-- Name: directus_folders; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_folders (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    parent uuid
);


ALTER TABLE public.directus_folders OWNER TO directus;

--
-- Name: directus_migrations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_migrations (
    version character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.directus_migrations OWNER TO directus;

--
-- Name: directus_notifications; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_notifications (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(255) DEFAULT 'inbox'::character varying,
    recipient uuid NOT NULL,
    sender uuid,
    subject character varying(255) NOT NULL,
    message text,
    collection character varying(64),
    item character varying(255)
);


ALTER TABLE public.directus_notifications OWNER TO directus;

--
-- Name: directus_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_notifications_id_seq OWNER TO directus;

--
-- Name: directus_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_notifications_id_seq OWNED BY public.directus_notifications.id;


--
-- Name: directus_operations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_operations (
    id uuid NOT NULL,
    name character varying(255),
    key character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    position_x integer NOT NULL,
    position_y integer NOT NULL,
    options json,
    resolve uuid,
    reject uuid,
    flow uuid NOT NULL,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


ALTER TABLE public.directus_operations OWNER TO directus;

--
-- Name: directus_panels; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_panels (
    id uuid NOT NULL,
    dashboard uuid NOT NULL,
    name character varying(255),
    icon character varying(30) DEFAULT NULL::character varying,
    color character varying(10),
    show_header boolean DEFAULT false NOT NULL,
    note text,
    type character varying(255) NOT NULL,
    position_x integer NOT NULL,
    position_y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    options json,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


ALTER TABLE public.directus_panels OWNER TO directus;

--
-- Name: directus_permissions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_permissions (
    id integer NOT NULL,
    role uuid,
    collection character varying(64) NOT NULL,
    action character varying(10) NOT NULL,
    permissions json,
    validation json,
    presets json,
    fields text
);


ALTER TABLE public.directus_permissions OWNER TO directus;

--
-- Name: directus_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_permissions_id_seq OWNER TO directus;

--
-- Name: directus_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_permissions_id_seq OWNED BY public.directus_permissions.id;


--
-- Name: directus_presets; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_presets (
    id integer NOT NULL,
    bookmark character varying(255),
    "user" uuid,
    role uuid,
    collection character varying(64),
    search character varying(100),
    layout character varying(100) DEFAULT 'tabular'::character varying,
    layout_query json,
    layout_options json,
    refresh_interval integer,
    filter json,
    icon character varying(30) DEFAULT 'bookmark_outline'::character varying NOT NULL,
    color character varying(255)
);


ALTER TABLE public.directus_presets OWNER TO directus;

--
-- Name: directus_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_presets_id_seq OWNER TO directus;

--
-- Name: directus_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_presets_id_seq OWNED BY public.directus_presets.id;


--
-- Name: directus_relations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_relations (
    id integer NOT NULL,
    many_collection character varying(64) NOT NULL,
    many_field character varying(64) NOT NULL,
    one_collection character varying(64),
    one_field character varying(64),
    one_collection_field character varying(64),
    one_allowed_collections text,
    junction_field character varying(64),
    sort_field character varying(64),
    one_deselect_action character varying(255) DEFAULT 'nullify'::character varying NOT NULL
);


ALTER TABLE public.directus_relations OWNER TO directus;

--
-- Name: directus_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_relations_id_seq OWNER TO directus;

--
-- Name: directus_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_relations_id_seq OWNED BY public.directus_relations.id;


--
-- Name: directus_revisions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_revisions (
    id integer NOT NULL,
    activity integer NOT NULL,
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    data json,
    delta json,
    parent integer
);


ALTER TABLE public.directus_revisions OWNER TO directus;

--
-- Name: directus_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_revisions_id_seq OWNER TO directus;

--
-- Name: directus_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_revisions_id_seq OWNED BY public.directus_revisions.id;


--
-- Name: directus_roles; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(30) DEFAULT 'supervised_user_circle'::character varying NOT NULL,
    description text,
    ip_access text,
    enforce_tfa boolean DEFAULT false NOT NULL,
    admin_access boolean DEFAULT false NOT NULL,
    app_access boolean DEFAULT true NOT NULL
);


ALTER TABLE public.directus_roles OWNER TO directus;

--
-- Name: directus_sessions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_sessions (
    token character varying(64) NOT NULL,
    "user" uuid,
    expires timestamp with time zone NOT NULL,
    ip character varying(255),
    user_agent character varying(255),
    share uuid
);


ALTER TABLE public.directus_sessions OWNER TO directus;

--
-- Name: directus_settings; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_settings (
    id integer NOT NULL,
    project_name character varying(100) DEFAULT 'Directus'::character varying NOT NULL,
    project_url character varying(255),
    project_color character varying(50) DEFAULT NULL::character varying,
    project_logo uuid,
    public_foreground uuid,
    public_background uuid,
    public_note text,
    auth_login_attempts integer DEFAULT 25,
    auth_password_policy character varying(100),
    storage_asset_transform character varying(7) DEFAULT 'all'::character varying,
    storage_asset_presets json,
    custom_css text,
    storage_default_folder uuid,
    basemaps json,
    mapbox_key character varying(255),
    module_bar json,
    project_descriptor character varying(100),
    translation_strings json,
    default_language character varying(255) DEFAULT 'en-US'::character varying NOT NULL,
    custom_aspect_ratios json
);


ALTER TABLE public.directus_settings OWNER TO directus;

--
-- Name: directus_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_settings_id_seq OWNER TO directus;

--
-- Name: directus_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_settings_id_seq OWNED BY public.directus_settings.id;


--
-- Name: directus_shares; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_shares (
    id uuid NOT NULL,
    name character varying(255),
    collection character varying(64),
    item character varying(255),
    role uuid,
    password character varying(255),
    user_created uuid,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    date_start timestamp with time zone,
    date_end timestamp with time zone,
    times_used integer DEFAULT 0,
    max_uses integer
);


ALTER TABLE public.directus_shares OWNER TO directus;

--
-- Name: directus_users; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_users (
    id uuid NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(128),
    password character varying(255),
    location character varying(255),
    title character varying(50),
    description text,
    tags json,
    avatar uuid,
    language character varying(255) DEFAULT NULL::character varying,
    theme character varying(20) DEFAULT 'auto'::character varying,
    tfa_secret character varying(255),
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    role uuid,
    token character varying(255),
    last_access timestamp with time zone,
    last_page character varying(255),
    provider character varying(128) DEFAULT 'default'::character varying NOT NULL,
    external_identifier character varying(255),
    auth_data json,
    email_notifications boolean DEFAULT true
);


ALTER TABLE public.directus_users OWNER TO directus;

--
-- Name: directus_webhooks; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_webhooks (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    url character varying(255) NOT NULL,
    status character varying(10) DEFAULT 'active'::character varying NOT NULL,
    data boolean DEFAULT true NOT NULL,
    actions character varying(100) NOT NULL,
    collections character varying(255) NOT NULL,
    headers json
);


ALTER TABLE public.directus_webhooks OWNER TO directus;

--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_webhooks_id_seq OWNER TO directus;

--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_webhooks_id_seq OWNED BY public.directus_webhooks.id;


--
-- Name: plant; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.plant (
    id integer NOT NULL,
    sort integer,
    date_updated timestamp with time zone,
    name character varying(255),
    photo uuid,
    notes text,
    plant_usage integer NOT NULL,
    location character varying(255),
    water_at timestamp without time zone,
    fertilize_at timestamp without time zone
);


ALTER TABLE public.plant OWNER TO directus;

--
-- Name: plant_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.plant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plant_id_seq OWNER TO directus;

--
-- Name: plant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.plant_id_seq OWNED BY public.plant.id;


--
-- Name: plant_usage; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.plant_usage (
    id integer NOT NULL,
    date_created timestamp with time zone,
    date_updated timestamp with time zone,
    sun character varying(255) DEFAULT 'direct'::character varying,
    fertilize_interval integer DEFAULT 14,
    type character varying(255),
    water_interval integer DEFAULT 7,
    water_amount real DEFAULT '250'::real
);


ALTER TABLE public.plant_usage OWNER TO directus;

--
-- Name: plant_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.plant_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plant_usage_id_seq OWNER TO directus;

--
-- Name: plant_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.plant_usage_id_seq OWNED BY public.plant_usage.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    name character varying(255),
    avatar uuid,
    score integer DEFAULT 0,
    water_times integer DEFAULT 0,
    fertilize_times integer DEFAULT 0
);


ALTER TABLE public."user" OWNER TO directus;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO directus;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: directus_activity id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_activity ALTER COLUMN id SET DEFAULT nextval('public.directus_activity_id_seq'::regclass);


--
-- Name: directus_fields id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_fields ALTER COLUMN id SET DEFAULT nextval('public.directus_fields_id_seq'::regclass);


--
-- Name: directus_notifications id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications ALTER COLUMN id SET DEFAULT nextval('public.directus_notifications_id_seq'::regclass);


--
-- Name: directus_permissions id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_permissions ALTER COLUMN id SET DEFAULT nextval('public.directus_permissions_id_seq'::regclass);


--
-- Name: directus_presets id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets ALTER COLUMN id SET DEFAULT nextval('public.directus_presets_id_seq'::regclass);


--
-- Name: directus_relations id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_relations ALTER COLUMN id SET DEFAULT nextval('public.directus_relations_id_seq'::regclass);


--
-- Name: directus_revisions id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions ALTER COLUMN id SET DEFAULT nextval('public.directus_revisions_id_seq'::regclass);


--
-- Name: directus_settings id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings ALTER COLUMN id SET DEFAULT nextval('public.directus_settings_id_seq'::regclass);


--
-- Name: directus_webhooks id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_webhooks ALTER COLUMN id SET DEFAULT nextval('public.directus_webhooks_id_seq'::regclass);


--
-- Name: plant id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.plant ALTER COLUMN id SET DEFAULT nextval('public.plant_id_seq'::regclass);


--
-- Name: plant_usage id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.plant_usage ALTER COLUMN id SET DEFAULT nextval('public.plant_usage_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: directus_activity; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_activity (id, action, "user", "timestamp", ip, user_agent, collection, item, comment) FROM stdin;
1	login	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-18 13:14:20.425+00	192.168.160.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36	directus_users	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N
\.


--
-- Data for Name: directus_collections; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_collections (collection, icon, note, display_template, hidden, singleton, translations, archive_field, archive_app_filter, archive_value, unarchive_value, sort_field, accountability, color, item_duplication_fields, sort, "group", collapse) FROM stdin;
plant	density_small	Contains plants	{{}}	f	f	\N	\N	f	archived	draft	sort	all	#00701C	[]	2	Planter	open
plant_usage	build_circle	Usage data of plants	\N	f	f	\N	\N	f	\N	\N	\N	all	#1C9B49	\N	3	Planter	open
user	\N	\N	\N	f	f	\N	\N	f	\N	\N	\N	all	\N	\N	1	users	open
users	folder	\N	\N	f	f	\N	\N	t	\N	\N	\N	all	\N	\N	2	\N	open
Planter	folder	\N	\N	f	f	\N	\N	t	\N	\N	\N	all	#108A00	\N	1	\N	open
\.


--
-- Data for Name: directus_dashboards; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_dashboards (id, name, icon, note, date_created, user_created, color) FROM stdin;
\.


--
-- Data for Name: directus_fields; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_fields (id, collection, field, special, interface, options, display, display_options, readonly, hidden, sort, width, translations, note, conditions, required, "group", validation, validation_message) FROM stdin;
4	plant	date_updated	date-updated,date-created	datetime	\N	datetime	{"relative":true}	t	t	3	half	\N	\N	\N	f	\N	\N	\N
5	plant	name	\N	input	{"placeholder":"Plant Name","iconLeft":"perm_contact_calendar"}	\N	\N	f	f	4	full	\N	\N	\N	t	\N	\N	\N
53	plant	water_at	\N	datetime	\N	datetime	{}	f	f	9	full	\N	\N	\N	t	\N	\N	\N
57	plant	fertilize_at	\N	datetime	\N	\N	\N	f	f	\N	full	\N	\N	\N	t	\N	\N	\N
38	user	id	\N	input	\N	\N	\N	t	t	\N	full	\N	\N	\N	f	\N	\N	\N
39	user	name	\N	input	{"placeholder":"Name","iconLeft":"account_circle"}	\N	\N	f	f	\N	full	\N	\N	\N	t	\N	\N	\N
36	plant	location	\N	input	{"placeholder":"Pflanzen Standort","iconLeft":"home"}	\N	\N	f	f	6	full	\N	\N	\N	t	\N	\N	\N
41	user	score	\N	input	{"min":0,"placeholder":"Punktzahl","iconLeft":"pin"}	\N	\N	f	f	\N	full	\N	\N	\N	f	\N	\N	\N
12	plant	notes	\N	input-multiline	{"placeholder":"Notizen","softLength":500,"font":"monospace","clear":true,"trim":true}	\N	\N	f	f	7	full	\N	\N	\N	f	\N	\N	\N
25	plant	plant_usage	m2o	select-dropdown-m2o	\N	related-values	\N	f	f	8	full	\N	Data of how to use this plant	\N	t	\N	\N	\N
40	user	avatar	file	file-image	{"folder":"395886ce-9528-4506-a663-7f7dc19dd38e"}	image	{"circle":true}	f	f	\N	full	\N	\N	\N	f	\N	\N	\N
43	user	fertilize_times	\N	input	{"min":0,"placeholder":"Anzahl an Düngungen"}	\N	\N	f	f	\N	full	\N	\N	\N	f	\N	\N	\N
42	user	water_times	\N	input	{"min":0,"placeholder":"Anzahl an Gießungen"}	\N	\N	f	f	\N	full	\N	\N	\N	f	\N	\N	\N
16	plant_usage	id	\N	input	\N	\N	\N	t	t	1	full	\N	\N	\N	f	\N	\N	\N
17	plant_usage	date_created	date-created	datetime	\N	datetime	{"relative":true}	t	t	2	half	\N	\N	\N	f	\N	\N	\N
18	plant_usage	date_updated	date-updated	datetime	\N	datetime	{"relative":true}	t	t	3	half	\N	\N	\N	f	\N	\N	\N
45	plant_usage	type	\N	input	{"placeholder":"Pflanzentyp"}	\N	\N	f	f	4	full	\N	\N	\N	t	\N	\N	\N
1	plant	id	\N	input	\N	\N	\N	t	t	1	full	\N	\N	\N	f	\N	\N	\N
3	plant	sort	\N	input	\N	\N	\N	f	t	2	half	\N	\N	\N	f	\N	\N	\N
55	plant_usage	water_interval	\N	input	{"minValue":1,"maxValue":28,"stepInterval":1,"min":7,"max":120,"placeholder":"Bewässerungsinterval","iconLeft":"water_drop"}	formatted-value	{"bold":true,"color":"#3399FF","icon":"water"}	f	f	5	half	\N	The cast interval for the plant	\N	t	\N	\N	\N
56	plant_usage	water_amount	\N	input	{"min":50,"max":2000,"step":50,"placeholder":"Wassermenge","iconLeft":"water_drop","font":"monospace"}	formatted-value	{"color":"#3399FF","icon":"water_drop"}	f	f	6	half	\N	\N	\N	t	\N	\N	\N
24	plant_usage	fertilize_interval	\N	input	{"minValue":7,"maxValue":91,"alwaysShowValue":true,"stepInterval":7,"min":1,"max":120,"placeholder":"Düngeintervall","iconLeft":"bug_report"}	formatted-value	{"color":"#613400","icon":"auto_delete"}	f	f	7	half	\N	\N	\N	t	\N	\N	\N
19	plant_usage	sun	\N	select-dropdown	{"choices":[{"text":"Direkt","value":"direct"},{"text":"Indirekt","value":"indirect"},{"text":"Halbschatten","value":"half_shadow"},{"text":"Schatten","value":"shadow"}],"icon":"light_mode","placeholder":"Lichtbedarf"}	formatted-value	{"icon":"wb_sunny","color":"#FFC23B"}	f	f	8	half	\N	\N	\N	t	\N	\N	\N
7	plant	photo	file	file-image	{"folder":"1360b31a-9fae-43bd-90bd-d7bf0425ec7f"}	image	{}	f	f	5	full	\N	\N	[]	f	\N	\N	\N
\.


--
-- Data for Name: directus_files; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_files (id, storage, filename_disk, filename_download, title, type, folder, uploaded_by, uploaded_on, modified_by, modified_on, charset, filesize, width, height, duration, embed, description, location, tags, metadata) FROM stdin;
98d3bdda-2ce1-4025-8c4f-beef2667d395	local	98d3bdda-2ce1-4025-8c4f-beef2667d395.webp	anika.webp	Anika	image/webp	395886ce-9528-4506-a663-7f7dc19dd38e	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-06-23 11:07:34.993751+00	\N	2022-06-23 11:07:35.03+00	\N	13686	250	250	\N	\N	\N	\N	\N	\N
34ae9839-bfd3-46f3-911b-538fa45726f9	local	34ae9839-bfd3-46f3-911b-538fa45726f9.webp	carolin.webp	Carolin	image/webp	395886ce-9528-4506-a663-7f7dc19dd38e	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-06-23 11:07:58.826184+00	\N	2022-06-23 11:07:58.885+00	\N	13532	250	250	\N	\N	\N	\N	\N	\N
a670aaa6-1416-4f48-a57d-b0cd0dc352bc	local	a670aaa6-1416-4f48-a57d-b0cd0dc352bc.png	plant.png	Plant	image/png	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-06-14 13:44:25.948455+00	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-18 12:59:18.748+00	\N	23495	512	512	\N	\N	\N	\N	\N	{}
dd7454d1-7dbf-4484-a364-0a6522a6fd43	local	dd7454d1-7dbf-4484-a364-0a6522a6fd43.jpeg	peter.jpeg	peter.jpeg	image/jpeg	1360b31a-9fae-43bd-90bd-d7bf0425ec7f	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-18 12:45:04.749743+00	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-18 12:45:27.293+00	\N	106458	1125	1500	\N	\N	\N	\N	["plant"]	{}
\.


--
-- Data for Name: directus_flows; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_flows (id, name, icon, color, description, status, trigger, accountability, options, operation, date_created, user_created) FROM stdin;
bc106116-48e7-484d-93d2-65386d6fe946	Reset User Stats	bolt	\N	\N	active	manual	activity	{"collections":["user"],"location":"collection","async":true}	ff06e1ee-27d2-4635-b4ad-6f3b270b7f14	2022-08-02 14:05:03.83+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
2cd5b692-fecb-495b-b5da-bab92552870f	Download new User/Plant Images	bolt	#0593FF	After setting new avatars or plant photos this flow is triggered	active	operation	all	{"return":"$all"}	43079873-1891-4d62-ab37-df485e5eea14	2022-08-12 14:14:51.451+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
f454a34b-29df-4fdc-971e-9da92a1302f8	Plant Updates Flow (WH)	build	#20EE24	Triggers on plant updates and calls a webhook to update UI	active	event	all	{"type":"action","scope":["items.create","items.update","items.delete"],"collections":["plant","plant_usage"]}	995bd303-bd74-47de-b693-be64366138e8	2022-08-12 14:18:02.857+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
14bbfd6a-7d16-4b0d-84b7-219697761793	User Updates Flow (WH)	build	#D314D7	Triggers on user updates and calls a webhook	active	event	all	{"type":"action","scope":["items.create","items.update","items.delete"],"collections":["user"]}	16260009-471c-4c54-9128-a0383f197cda	2022-08-12 14:20:02.762+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
\.


--
-- Data for Name: directus_folders; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_folders (id, name, parent) FROM stdin;
c5d35a69-7dbc-499b-ad7c-452b5de18407	images	\N
1360b31a-9fae-43bd-90bd-d7bf0425ec7f	plants	c5d35a69-7dbc-499b-ad7c-452b5de18407
395886ce-9528-4506-a663-7f7dc19dd38e	avatars	c5d35a69-7dbc-499b-ad7c-452b5de18407
\.


--
-- Data for Name: directus_migrations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_migrations (version, name, "timestamp") FROM stdin;
20201028A	Remove Collection Foreign Keys	2022-06-14 13:42:19.938088+00
20201029A	Remove System Relations	2022-06-14 13:42:19.947342+00
20201029B	Remove System Collections	2022-06-14 13:42:19.952003+00
20201029C	Remove System Fields	2022-06-14 13:42:19.960776+00
20201105A	Add Cascade System Relations	2022-06-14 13:42:20.05289+00
20201105B	Change Webhook URL Type	2022-06-14 13:42:20.058672+00
20210225A	Add Relations Sort Field	2022-06-14 13:42:20.063293+00
20210304A	Remove Locked Fields	2022-06-14 13:42:20.067954+00
20210312A	Webhooks Collections Text	2022-06-14 13:42:20.07206+00
20210331A	Add Refresh Interval	2022-06-14 13:42:20.074977+00
20210415A	Make Filesize Nullable	2022-06-14 13:42:20.082769+00
20210416A	Add Collections Accountability	2022-06-14 13:42:20.089269+00
20210422A	Remove Files Interface	2022-06-14 13:42:20.092646+00
20210506A	Rename Interfaces	2022-06-14 13:42:20.121821+00
20210510A	Restructure Relations	2022-06-14 13:42:20.154568+00
20210518A	Add Foreign Key Constraints	2022-06-14 13:42:20.173126+00
20210519A	Add System Fk Triggers	2022-06-14 13:42:20.224561+00
20210521A	Add Collections Icon Color	2022-06-14 13:42:20.228221+00
20210525A	Add Insights	2022-06-14 13:42:20.267022+00
20210608A	Add Deep Clone Config	2022-06-14 13:42:20.270531+00
20210626A	Change Filesize Bigint	2022-06-14 13:42:20.289257+00
20210716A	Add Conditions to Fields	2022-06-14 13:42:20.292269+00
20210721A	Add Default Folder	2022-06-14 13:42:20.299589+00
20210802A	Replace Groups	2022-06-14 13:42:20.30392+00
20210803A	Add Required to Fields	2022-06-14 13:42:20.307941+00
20210805A	Update Groups	2022-06-14 13:42:20.31079+00
20210805B	Change Image Metadata Structure	2022-06-14 13:42:20.313693+00
20210811A	Add Geometry Config	2022-06-14 13:42:20.316688+00
20210831A	Remove Limit Column	2022-06-14 13:42:20.319202+00
20210903A	Add Auth Provider	2022-06-14 13:42:20.338527+00
20210907A	Webhooks Collections Not Null	2022-06-14 13:42:20.343312+00
20210910A	Move Module Setup	2022-06-14 13:42:20.348439+00
20210920A	Webhooks URL Not Null	2022-06-14 13:42:20.353369+00
20210924A	Add Collection Organization	2022-06-14 13:42:20.361814+00
20210927A	Replace Fields Group	2022-06-14 13:42:20.371341+00
20210927B	Replace M2M Interface	2022-06-14 13:42:20.374309+00
20210929A	Rename Login Action	2022-06-14 13:42:20.376794+00
20211007A	Update Presets	2022-06-14 13:42:20.382007+00
20211009A	Add Auth Data	2022-06-14 13:42:20.384562+00
20211016A	Add Webhook Headers	2022-06-14 13:42:20.387678+00
20211103A	Set Unique to User Token	2022-06-14 13:42:20.392641+00
20211103B	Update Special Geometry	2022-06-14 13:42:20.396311+00
20211104A	Remove Collections Listing	2022-06-14 13:42:20.398943+00
20211118A	Add Notifications	2022-06-14 13:42:20.435953+00
20211211A	Add Shares	2022-06-14 13:42:20.46816+00
20211230A	Add Project Descriptor	2022-06-14 13:42:20.47246+00
20220303A	Remove Default Project Color	2022-06-14 13:42:20.478956+00
20220308A	Add Bookmark Icon and Color	2022-06-14 13:42:20.483294+00
20220314A	Add Translation Strings	2022-06-14 13:42:20.4868+00
20220322A	Rename Field Typecast Flags	2022-06-14 13:42:20.490089+00
20220323A	Add Field Validation	2022-06-14 13:42:20.493497+00
20220325A	Fix Typecast Flags	2022-06-14 13:42:20.497328+00
20220325B	Add Default Language	2022-06-14 13:42:20.504977+00
20220402A	Remove Default Value Panel Icon	2022-06-14 13:42:20.509919+00
20220429A	Add Flows	2022-06-14 13:42:20.571527+00
20220429B	Add Color to Insights Icon	2022-06-14 13:42:20.574534+00
20220429C	Drop Non Null from IP of Activity	2022-06-14 13:42:20.576738+00
20220429D	Drop Non Null from Sender of Notifications	2022-06-14 13:42:20.579187+00
20220614A	Rename Hook Trigger to Event	2022-07-15 13:44:44.520011+00
20220801A	Update Notifications Timestamp Column	2022-08-05 08:27:46.198234+00
20220802A	Add Custom Aspect Ratios	2022-08-05 08:27:46.21054+00
\.


--
-- Data for Name: directus_notifications; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_notifications (id, "timestamp", status, recipient, sender, subject, message, collection, item) FROM stdin;
\.


--
-- Data for Name: directus_operations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_operations (id, name, key, type, position_x, position_y, options, resolve, reject, flow, date_created, user_created) FROM stdin;
b4f9c71a-5b91-4827-a7b0-3dd8bb1cbc2d	Update Plants Webhook	update_plants_webhook_2	request	58	27	{"url":"http://websocket:60001/update_plants"}	\N	\N	f454a34b-29df-4fdc-971e-9da92a1302f8	2022-08-12 14:43:55.763+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
0690d43c-8121-41fe-aab8-f302215cb926	Call Image Download Flow	call_image_download_flow	trigger	19	24	{"flow":"2cd5b692-fecb-495b-b5da-bab92552870f","payload":"{{$trigger}}"}	b4f9c71a-5b91-4827-a7b0-3dd8bb1cbc2d	\N	f454a34b-29df-4fdc-971e-9da92a1302f8	2022-08-12 14:43:55.777+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
5ab44ff0-5e36-4c99-8c9b-e4a9e9d53847	Update Plants Webhook 	update_plants_webhook	request	58	11	{"url":"http://websocket:60001/update_plants"}	\N	\N	f454a34b-29df-4fdc-971e-9da92a1302f8	2022-08-12 14:18:54.497+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
995bd303-bd74-47de-b693-be64366138e8	has changed Photo	has_changed_photo	condition	19	1	{"filter":{"$trigger":{"payload":{"photo":{"_submitted":true}}}}}	0690d43c-8121-41fe-aab8-f302215cb926	5ab44ff0-5e36-4c99-8c9b-e4a9e9d53847	f454a34b-29df-4fdc-971e-9da92a1302f8	2022-08-12 14:43:55.802+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
6a8430db-aebb-4bfe-b8cf-2307e94f7501	Update Users Webhook	update_users_webhook_2	request	56	28	{"url":"http://websocket:60001/update_users"}	\N	\N	14bbfd6a-7d16-4b0d-84b7-219697761793	2022-08-15 11:21:08.159+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
040f1faf-e8a1-4c0f-83e8-de389a212e0d	Call Image Download Flow	call_image_download_flow	trigger	19	22	{"flow":"2cd5b692-fecb-495b-b5da-bab92552870f","payload":"{{$trigger}}"}	6a8430db-aebb-4bfe-b8cf-2307e94f7501	\N	14bbfd6a-7d16-4b0d-84b7-219697761793	2022-08-15 11:21:08.169+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
2a02a77b-57b6-493b-8894-fa45a64a8405	UPDATE WEBHOOK	update_webhook	request	37	1	{"url":"http://websocket:60001/update_users"}	\N	\N	bc106116-48e7-484d-93d2-65386d6fe946	2022-08-05 14:04:10.553+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
81ef6b3f-dd40-451c-898b-9452e1365a21	Log to Console	log_isjb7	log	37	17	{"message":"Score Reset fehlgeschlagen"}	\N	\N	bc106116-48e7-484d-93d2-65386d6fe946	2022-08-02 14:10:04.299+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
ff06e1ee-27d2-4635-b4ad-6f3b270b7f14	Daten aktualisieren	update_scores_and_times	item-update	19	1	{"collection":"user","payload":{"score":0,"water_times":0,"fertilize_times":0},"query":{}}	2a02a77b-57b6-493b-8894-fa45a64a8405	81ef6b3f-dd40-451c-898b-9452e1365a21	bc106116-48e7-484d-93d2-65386d6fe946	2022-08-02 14:05:58.795+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
43079873-1891-4d62-ab37-df485e5eea14	Call Image Refresh Webhook	call_image_refresh_webhook	request	19	1	{"method":"POST","url":"http://planter:61000/api/image_refresh","body":"{{$trigger}}"}	\N	\N	2cd5b692-fecb-495b-b5da-bab92552870f	2022-08-12 14:15:52.527+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
db4b913f-f108-4e45-83bf-dec1236a2fe7	Update Users Webhook	update_users_webhook	request	56	10	{"url":"http://websocket:60001/update_users"}	\N	\N	14bbfd6a-7d16-4b0d-84b7-219697761793	2022-08-12 14:20:19.066+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
16260009-471c-4c54-9128-a0383f197cda	has avatar	has_avatar	condition	19	1	{"filter":{"$trigger":{"payload":{"avatar":{"_submitted":true}}}}}	040f1faf-e8a1-4c0f-83e8-de389a212e0d	db4b913f-f108-4e45-83bf-dec1236a2fe7	14bbfd6a-7d16-4b0d-84b7-219697761793	2022-08-15 11:21:08.192+00	9d994631-8838-4d6f-b0ed-ea850ecdca33
\.


--
-- Data for Name: directus_panels; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_panels (id, dashboard, name, icon, color, show_header, note, type, position_x, position_y, width, height, options, date_created, user_created) FROM stdin;
\.


--
-- Data for Name: directus_permissions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_permissions (id, role, collection, action, permissions, validation, presets, fields) FROM stdin;
25	70624f62-72f6-4215-a8a5-9c77eb17e429	plant	create	{}	{}	\N	*
26	70624f62-72f6-4215-a8a5-9c77eb17e429	plant	read	{}	{}	\N	*
27	70624f62-72f6-4215-a8a5-9c77eb17e429	plant	update	{}	{}	\N	*
28	70624f62-72f6-4215-a8a5-9c77eb17e429	plant	delete	{}	{}	\N	*
35	70624f62-72f6-4215-a8a5-9c77eb17e429	plant_usage	create	{}	{}	\N	*
36	70624f62-72f6-4215-a8a5-9c77eb17e429	plant_usage	read	{}	{}	\N	*
37	70624f62-72f6-4215-a8a5-9c77eb17e429	plant_usage	update	{}	{}	\N	*
38	70624f62-72f6-4215-a8a5-9c77eb17e429	plant_usage	delete	{}	{}	\N	*
139	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_files	create	{}	\N	\N	*
140	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_files	read	{}	\N	\N	*
141	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_files	update	{}	\N	\N	*
142	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_files	delete	{}	\N	\N	*
143	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_dashboards	create	{}	\N	\N	*
144	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_dashboards	read	{}	\N	\N	*
145	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_dashboards	update	{}	\N	\N	*
146	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_dashboards	delete	{}	\N	\N	*
147	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_panels	create	{}	\N	\N	*
148	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_panels	read	{}	\N	\N	*
149	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_panels	update	{}	\N	\N	*
150	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_panels	delete	{}	\N	\N	*
151	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_folders	create	{}	\N	\N	*
152	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_folders	read	{}	\N	\N	*
153	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_folders	update	{}	\N	\N	*
154	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_folders	delete	{}	\N	\N	\N
155	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_users	read	{}	\N	\N	*
156	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_users	update	{"id":{"_eq":"$CURRENT_USER"}}	\N	\N	first_name,last_name,email,password,location,title,description,avatar,language,theme,tfa_secret
157	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_roles	read	{}	\N	\N	*
158	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_shares	read	{"_or":[{"role":{"_eq":"$CURRENT_ROLE"}},{"role":{"_null":true}}]}	\N	\N	*
159	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_shares	create	{}	\N	\N	*
160	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_shares	update	{"user_created":{"_eq":"$CURRENT_USER"}}	\N	\N	*
161	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_shares	delete	{"user_created":{"_eq":"$CURRENT_USER"}}	\N	\N	*
162	70624f62-72f6-4215-a8a5-9c77eb17e429	directus_flows	read	{"trigger":{"_eq":"manual"}}	\N	\N	id,name,icon,color,options,trigger
65	70624f62-72f6-4215-a8a5-9c77eb17e429	user	create	{}	{}	\N	*
66	70624f62-72f6-4215-a8a5-9c77eb17e429	user	read	{}	{}	\N	*
67	70624f62-72f6-4215-a8a5-9c77eb17e429	user	update	{}	{}	\N	*
\.


--
-- Data for Name: directus_presets; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_presets (id, bookmark, "user", role, collection, search, layout, layout_query, layout_options, refresh_interval, filter, icon, color) FROM stdin;
8	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N	user	\N	\N	{"tabular":{"fields":["id","avatar","name","score","water_times","fertilize_times"]}}	{"tabular":{"widths":{}}}	\N	\N	bookmark_outline	\N
9	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N	directus_webhooks	\N	tabular	{"tabular":{"fields":["status","method","name","collections","actions","data"]}}	{"tabular":{"widths":{"status":32,"method":100,"name":210,"collections":240,"actions":308.56640625}}}	\N	\N	bookmark_outline	\N
12	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N	directus_users	\N	cards	{"cards":{"sort":["email"],"page":1}}	{"cards":{"icon":"account_circle","title":"{{ first_name }} {{ last_name }}","subtitle":"{{ email }}","size":4}}	\N	\N	bookmark_outline	\N
6	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N	plant_usage	\N	\N	{"tabular":{"page":1,"fields":["id","type","sun","fertilize_interval","water_interval","water_amount"]}}	{"tabular":{"widths":{}}}	\N	\N	bookmark_outline	\N
7	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N	directus_files	\N	cards	{"cards":{"sort":["-uploaded_on"],"page":1}}	{"cards":{"icon":"insert_drive_file","title":"{{ title }}","subtitle":"{{ type }} • {{ filesize }}","size":4,"imageFit":"crop"}}	\N	\N	bookmark_outline	\N
5	\N	9d994631-8838-4d6f-b0ed-ea850ecdca33	\N	plant	\N	\N	{"tabular":{"page":1,"fields":["id","name","photo","location","plant_usage.sun","plant_usage.water_interval","plant_usage.water_amount","plant_usage.fertilize_interval","plant_usage.type","water_at","fertilize_at"]}}	{"tabular":{"spacing":"cozy","widths":{"id":91.49609375,"photo":96.13671875,"water_at":205.5390625}}}	\N	\N	bookmark_outline	\N
\.


--
-- Data for Name: directus_relations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_relations (id, many_collection, many_field, one_collection, one_field, one_collection_field, one_allowed_collections, junction_field, sort_field, one_deselect_action) FROM stdin;
1	plant	photo	directus_files	\N	\N	\N	\N	\N	nullify
2	plant	plant_usage	plant_usage	\N	\N	\N	\N	\N	nullify
5	user	avatar	directus_files	\N	\N	\N	\N	\N	nullify
\.


--
-- Data for Name: directus_revisions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_revisions (id, activity, collection, item, data, delta, parent) FROM stdin;
\.


--
-- Data for Name: directus_roles; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_roles (id, name, icon, description, ip_access, enforce_tfa, admin_access, app_access) FROM stdin;
dcecc508-eaf4-4845-bd20-2a1b69af16f7	Administrator	verified	$t:admin_description	\N	f	t	t
70624f62-72f6-4215-a8a5-9c77eb17e429	Website User	build	Tablet / Website API User	\N	f	f	t
\.


--
-- Data for Name: directus_sessions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_sessions (token, "user", expires, ip, user_agent, share) FROM stdin;
KyyNsHXrEqNZMntgtpKcv9bNFOUYETj7LuQvIlm5blLxp4U4pCRniaWLfXkZj11O	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-19 15:19:35.671+00	172.29.41.65	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36	\N
J2LyhcPvLcAJH3yTGhogV_soPMCq_Cj5JCpRZK0V2bzzBxy75aqyYctgXqvP2O_l	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-23 12:55:56.641+00	172.29.41.65	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36	\N
qFSeEOg7P_dsMnqNQI5KbvxGGH5J1jqrVcnxPuxge657qlPWzwEEbojWIIuazyIs	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-25 12:58:26.595+00	192.168.96.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36	\N
6rkUQVshSf6eZTNapta0GNn723wej4Ab1FOmBRM-h0xxuo5Nwqjefg9o4Va6TGaE	9d994631-8838-4d6f-b0ed-ea850ecdca33	2022-08-25 13:14:20.399+00	192.168.160.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36	\N
\.


--
-- Data for Name: directus_settings; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_settings (id, project_name, project_url, project_color, project_logo, public_foreground, public_background, public_note, auth_login_attempts, auth_password_policy, storage_asset_transform, storage_asset_presets, custom_css, storage_default_folder, basemaps, mapbox_key, module_bar, project_descriptor, translation_strings, default_language, custom_aspect_ratios) FROM stdin;
1	Planter	\N	#03919B	a670aaa6-1416-4f48-a57d-b0cd0dc352bc	\N	\N	Plant management for lazy people	10	/^.{8,}$/	presets	[{"key":"crop","fit":"inside","width":300,"height":500,"quality":80,"withoutEnlargement":false,"format":"webp","transforms":[]}]	#app .public-view .art .note-container .note {\n \tfont-size: 3rem;   \n    max-width: fit-content;\n    font-variant: small-caps;\n}\n	\N	\N		[{"type":"module","id":"content","enabled":true},{"type":"module","id":"users","enabled":true},{"type":"module","id":"files","enabled":true},{"type":"module","id":"insights","enabled":true},{"type":"module","id":"docs","enabled":true},{"type":"module","id":"settings","enabled":true,"locked":true}]	Plant management for lazy people	\N	de-DE	\N
\.


--
-- Data for Name: directus_shares; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_shares (id, name, collection, item, role, password, user_created, date_created, date_start, date_end, times_used, max_uses) FROM stdin;
\.


--
-- Data for Name: directus_users; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_users (id, first_name, last_name, email, password, location, title, description, tags, avatar, language, theme, tfa_secret, status, role, token, last_access, last_page, provider, external_identifier, auth_data, email_notifications) FROM stdin;
07343555-80fb-4578-9659-e35333957c7f	Website	User	api@planter.app	$argon2i$v=19$m=4096,t=3,p=1$Jt3TmBjhvq5j3wsmKKDZxA$lfQiDokkrq1awBZFwl+FK1QavSDXa51Ax9HQ6ZxcPGQ	\N	\N	\N	\N	\N	\N	auto	\N	active	70624f62-72f6-4215-a8a5-9c77eb17e429	pYNkngRMP18gj0TNM6xC0iSpSVGRICR5	\N	\N	default	\N	\N	f
9d994631-8838-4d6f-b0ed-ea850ecdca33	Admin	\N	admin@planter.app	$argon2id$v=19$m=4096,t=3,p=1$m0hF8Vi+Oc7H6W4DDmLWNg$/Kjcq5ChVYvkTQIIVvhpC/bP1M4Je5ETWXOf3UbhJtM	\N	\N	\N	\N	\N	en-US	dark	\N	active	dcecc508-eaf4-4845-bd20-2a1b69af16f7	\N	2022-08-18 13:14:20.434+00	/users	default	\N	\N	t
\.


--
-- Data for Name: directus_webhooks; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_webhooks (id, name, method, url, status, data, actions, collections, headers) FROM stdin;
\.


--
-- Data for Name: plant; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.plant (id, sort, date_updated, name, photo, notes, plant_usage, location, water_at, fertilize_at) FROM stdin;
1	\N	2022-08-18 12:45:27.316+00	Peter	dd7454d1-7dbf-4484-a364-0a6522a6fd43	\N	1	Office 1	2022-08-08 11:25:00	2022-08-05 15:47:45.758
2	\N	2022-08-18 12:51:06.69+00	Plant 2	\N		2	Office 1	2022-08-18 12:50:45.091	2022-08-18 12:51:06.66
\.


--
-- Data for Name: plant_usage; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.plant_usage (id, date_created, date_updated, sun, fertilize_interval, type, water_interval, water_amount) FROM stdin;
3	2022-06-16 13:55:31.769+00	2022-06-24 10:29:19.391+00	indirect	90	Chinesische Feige	7	250
6	2022-06-28 11:31:57.327+00	\N	indirect	30	Drachenbaum	7	250
5	2022-06-24 10:36:51.924+00	2022-06-28 14:53:58.044+00	indirect	180	Bogenhanf	12	250
4	2022-06-16 13:55:58.672+00	2022-06-28 14:54:02.261+00	shadow	14	Glücksfeder	12	250
2	2022-06-16 13:55:08.966+00	2022-06-28 14:54:58.241+00	indirect	28	Strahlenaralie	7	750
7	2022-08-10 11:49:03.833+00	\N	indirect	30	Schwertfarn	4	150
8	2022-08-10 11:53:54.183+00	\N	half_shadow	30	Goldfruchtpalme	7	250
9	2022-08-10 11:55:41.403+00	\N	indirect	30	Orchidee	7	150
11	2022-08-10 12:01:06.011+00	\N	direct	60	Geldbaum	14	250
10	2022-08-10 11:58:35.616+00	2022-08-10 12:24:35.047+00	direct	365	Flammendes Kätchen	14	250
12	2022-08-15 14:57:28.66+00	\N	half_shadow	14	Monstera	7	250
13	2022-08-15 15:17:16.299+00	\N	half_shadow	14	Birkenfeige	7	250
1	2022-06-16 13:54:23.123+00	2022-08-15 15:17:49.604+00	indirect	14	Yucca	10	250
14	2022-08-15 15:19:10.553+00	\N	half_shadow	21	Gummibaum	7	125
15	2022-08-15 15:20:32.135+00	\N	direct	128	Aloe Vera	10	125
16	2022-08-15 15:22:33.311+00	\N	half_shadow	14	Geigenfeige	7	375
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."user" (id, name, avatar, score, water_times, fertilize_times) FROM stdin;
2	Anika	98d3bdda-2ce1-4025-8c4f-beef2667d395	40	4	0
1	Lisa	34ae9839-bfd3-46f3-911b-538fa45726f9	5	0	1
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: directus
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: directus
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: directus
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: directus
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: directus
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: directus
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: directus_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_activity_id_seq', 1, true);


--
-- Name: directus_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_fields_id_seq', 57, true);


--
-- Name: directus_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_notifications_id_seq', 1, false);


--
-- Name: directus_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_permissions_id_seq', 162, true);


--
-- Name: directus_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_presets_id_seq', 12, true);


--
-- Name: directus_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_relations_id_seq', 6, true);


--
-- Name: directus_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_revisions_id_seq', 1, false);


--
-- Name: directus_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_settings_id_seq', 1, true);


--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_webhooks_id_seq', 3, true);


--
-- Name: plant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.plant_id_seq', 3, false);


--
-- Name: plant_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.plant_usage_id_seq', 16, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.user_id_seq', 3, false);


--
-- Name: directus_activity directus_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_activity
    ADD CONSTRAINT directus_activity_pkey PRIMARY KEY (id);


--
-- Name: directus_collections directus_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_collections
    ADD CONSTRAINT directus_collections_pkey PRIMARY KEY (collection);


--
-- Name: directus_dashboards directus_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_dashboards
    ADD CONSTRAINT directus_dashboards_pkey PRIMARY KEY (id);


--
-- Name: directus_fields directus_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_fields
    ADD CONSTRAINT directus_fields_pkey PRIMARY KEY (id);


--
-- Name: directus_files directus_files_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_pkey PRIMARY KEY (id);


--
-- Name: directus_flows directus_flows_operation_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_operation_unique UNIQUE (operation);


--
-- Name: directus_flows directus_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_pkey PRIMARY KEY (id);


--
-- Name: directus_folders directus_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_folders
    ADD CONSTRAINT directus_folders_pkey PRIMARY KEY (id);


--
-- Name: directus_migrations directus_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_migrations
    ADD CONSTRAINT directus_migrations_pkey PRIMARY KEY (version);


--
-- Name: directus_notifications directus_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_pkey PRIMARY KEY (id);


--
-- Name: directus_operations directus_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_pkey PRIMARY KEY (id);


--
-- Name: directus_operations directus_operations_reject_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_reject_unique UNIQUE (reject);


--
-- Name: directus_operations directus_operations_resolve_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_resolve_unique UNIQUE (resolve);


--
-- Name: directus_panels directus_panels_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_pkey PRIMARY KEY (id);


--
-- Name: directus_permissions directus_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_permissions
    ADD CONSTRAINT directus_permissions_pkey PRIMARY KEY (id);


--
-- Name: directus_presets directus_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_pkey PRIMARY KEY (id);


--
-- Name: directus_relations directus_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_relations
    ADD CONSTRAINT directus_relations_pkey PRIMARY KEY (id);


--
-- Name: directus_revisions directus_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_pkey PRIMARY KEY (id);


--
-- Name: directus_roles directus_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_roles
    ADD CONSTRAINT directus_roles_pkey PRIMARY KEY (id);


--
-- Name: directus_sessions directus_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_pkey PRIMARY KEY (token);


--
-- Name: directus_settings directus_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_pkey PRIMARY KEY (id);


--
-- Name: directus_shares directus_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_pkey PRIMARY KEY (id);


--
-- Name: directus_users directus_users_email_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_email_unique UNIQUE (email);


--
-- Name: directus_users directus_users_external_identifier_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_external_identifier_unique UNIQUE (external_identifier);


--
-- Name: directus_users directus_users_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_pkey PRIMARY KEY (id);


--
-- Name: directus_users directus_users_token_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_token_unique UNIQUE (token);


--
-- Name: directus_webhooks directus_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_webhooks
    ADD CONSTRAINT directus_webhooks_pkey PRIMARY KEY (id);


--
-- Name: plant plant_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.plant
    ADD CONSTRAINT plant_pkey PRIMARY KEY (id);


--
-- Name: plant_usage plant_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.plant_usage
    ADD CONSTRAINT plant_usage_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: directus_collections directus_collections_group_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_collections
    ADD CONSTRAINT directus_collections_group_foreign FOREIGN KEY ("group") REFERENCES public.directus_collections(collection);


--
-- Name: directus_dashboards directus_dashboards_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_dashboards
    ADD CONSTRAINT directus_dashboards_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_files directus_files_folder_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_folder_foreign FOREIGN KEY (folder) REFERENCES public.directus_folders(id) ON DELETE SET NULL;


--
-- Name: directus_files directus_files_modified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_modified_by_foreign FOREIGN KEY (modified_by) REFERENCES public.directus_users(id);


--
-- Name: directus_files directus_files_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.directus_users(id);


--
-- Name: directus_flows directus_flows_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_folders directus_folders_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_folders
    ADD CONSTRAINT directus_folders_parent_foreign FOREIGN KEY (parent) REFERENCES public.directus_folders(id);


--
-- Name: directus_notifications directus_notifications_recipient_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_recipient_foreign FOREIGN KEY (recipient) REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_notifications directus_notifications_sender_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_sender_foreign FOREIGN KEY (sender) REFERENCES public.directus_users(id);


--
-- Name: directus_operations directus_operations_flow_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_flow_foreign FOREIGN KEY (flow) REFERENCES public.directus_flows(id) ON DELETE CASCADE;


--
-- Name: directus_operations directus_operations_reject_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_reject_foreign FOREIGN KEY (reject) REFERENCES public.directus_operations(id);


--
-- Name: directus_operations directus_operations_resolve_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_resolve_foreign FOREIGN KEY (resolve) REFERENCES public.directus_operations(id);


--
-- Name: directus_operations directus_operations_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_panels directus_panels_dashboard_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_dashboard_foreign FOREIGN KEY (dashboard) REFERENCES public.directus_dashboards(id) ON DELETE CASCADE;


--
-- Name: directus_panels directus_panels_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_permissions directus_permissions_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_permissions
    ADD CONSTRAINT directus_permissions_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_presets directus_presets_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_presets directus_presets_user_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_user_foreign FOREIGN KEY ("user") REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_revisions directus_revisions_activity_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_activity_foreign FOREIGN KEY (activity) REFERENCES public.directus_activity(id) ON DELETE CASCADE;


--
-- Name: directus_revisions directus_revisions_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_parent_foreign FOREIGN KEY (parent) REFERENCES public.directus_revisions(id);


--
-- Name: directus_sessions directus_sessions_share_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_share_foreign FOREIGN KEY (share) REFERENCES public.directus_shares(id) ON DELETE CASCADE;


--
-- Name: directus_sessions directus_sessions_user_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_user_foreign FOREIGN KEY ("user") REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_settings directus_settings_project_logo_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_project_logo_foreign FOREIGN KEY (project_logo) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_background_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_background_foreign FOREIGN KEY (public_background) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_foreground_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_foreground_foreign FOREIGN KEY (public_foreground) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_storage_default_folder_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_storage_default_folder_foreign FOREIGN KEY (storage_default_folder) REFERENCES public.directus_folders(id) ON DELETE SET NULL;


--
-- Name: directus_shares directus_shares_collection_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_collection_foreign FOREIGN KEY (collection) REFERENCES public.directus_collections(collection) ON DELETE CASCADE;


--
-- Name: directus_shares directus_shares_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_shares directus_shares_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_users directus_users_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE SET NULL;


--
-- Name: plant plant_photo_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.plant
    ADD CONSTRAINT plant_photo_foreign FOREIGN KEY (photo) REFERENCES public.directus_files(id) ON DELETE SET DEFAULT;


--
-- Name: plant plant_plant_usage_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.plant
    ADD CONSTRAINT plant_plant_usage_foreign FOREIGN KEY (plant_usage) REFERENCES public.plant_usage(id);


--
-- Name: user user_avatar_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_avatar_foreign FOREIGN KEY (avatar) REFERENCES public.directus_files(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

